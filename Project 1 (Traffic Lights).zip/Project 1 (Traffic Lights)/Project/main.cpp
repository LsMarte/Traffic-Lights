/*
 * Name: Luis Marte
 * Project 1: Traffic Lights
 * Course: CSI108 (Fall 2024)
 * Date: November 24, 2024
 * Description: Move a car along a road through a sequence of traffic lights.
 * This code defines the TrafficLight class with the necessary data members and member functions. 
   It also contains the non-member functions: (setLightDuration and displayTrafficLights)
   to set the light duration and display the traffic lights appropriately.
   The main function demonstrates the use of the TrafficLight class and its member functions.
   This code also has the added benefit of making the number of traffic lights on the road dynamic.
   This is obtained by allowing the user to input the number of traffic lights via dynamic arrays in the main() function.
 */

#include <iostream>  
#include <string>  
#include <cctype>  // for tolower()  
#include <cstdlib> // for rand()  
#include <ctime>  // for time() 
#include <limits> // it defines a numeric_limits 
using namespace std;

// TrafficLight class definition.  
class TrafficLight
{
public:
    // Default number of timesteps for each light.  
     static const int DEFAULT_LIGHT_DURATION;

    // Initialize with no lights.  
    TrafficLight();

    // Initialize with names for each light.  
    TrafficLight(const string initLights[], int initNumLights);

    // Copy constructor  
    TrafficLight(const TrafficLight& other);

    // Destructor  
    ~TrafficLight();

    // Return name of currently-lit light.  
    string getCurrentLight() const;

    // Accesor to Get time left on the light's timer  
    int getTimeLeft() const;

    // mutator to Set the duration for each light  
    void setLightDuration(int duration);

    // Assignment operator  
    TrafficLight& operator=(const TrafficLight& other);
    // Friend function to advance the traffic light's timer  
    friend TrafficLight& operator++(TrafficLight& light);


private:
    // Dynamic array of light names (e.g., green or red or  
    // even green-left) in order will trigger, not in order  
    // displayed on a physical traffic light.  
    string* lights;

    // Number of lights in array.  
    int numLights;

    // Index of current light (0 = first light in array).  
    int currentLight;

    // Duration in time steps for all lights. I.e., number  
    // of time steps after which goes to next light.  
    int lightDuration;

    // Timer to count out time of each light.  
    int timer;
};


// Prototypes for functions dealing with traffic lights.

//Function to set the duration for a traffic light
// Function to display traffic lights  
void displayTrafficLights(TrafficLight lights[], int size);

// Function to set the duration for a traffic light  
void setLightDuration(TrafficLight& light);



const int TrafficLight::DEFAULT_LIGHT_DURATION = 4;




int main()
{
    // Seed random number generator to randomize intersection  
    // placement, initial lights, and yellow light behavior.  
    // Don't uncomment until debug any problems.
    srand((unsigned int)time(NULL));

    // Define standard traffic light color sequences.  
    const string SEQUENCE_NORMAL[] = { "green", "yellow", "red" };
    const string SEQUENCE_ABBREV[] = { "green", "red" };

    // Create standard traffic light objects.  
    // Note: Computing # of elements using sizeof() only  
    // works for statically-allocated array (and not in  
    // a function to which they are passed).  
    const TrafficLight LIGHT_NORMAL(
        SEQUENCE_NORMAL, sizeof(SEQUENCE_NORMAL) / sizeof(SEQUENCE_NORMAL[0]));
    const TrafficLight LIGHT_ABBREV(
        SEQUENCE_ABBREV, sizeof(SEQUENCE_ABBREV) / sizeof(SEQUENCE_ABBREV[0]));

    // Store traffic light at each intersection (signals).  
    const int NUM_SIGNALS = 4;
    TrafficLight signals[NUM_SIGNALS];

    // Store position of signals along road using parallel  
    // array (signalPos). Each signal may be from DISTANCE_MIN  
    // to DISTANCE_MAX units apart.  
    const int DISTANCE_MIN = 3;
    const int DISTANCE_MAX = 7;
    int signalPos[NUM_SIGNALS];

    // Accumulate total length of road in generic units.  
    int roadLength = 0;

    // Generate random length of each road section leading to an  
    // intersection, allow user to choose type of traffic light  
    // at intersection, and decide how long each light lasts.  
    for (int intersection = 0; intersection < NUM_SIGNALS; intersection++)
    {
        // Determine random distance to next signal.  
        roadLength += DISTANCE_MIN + rand() % (DISTANCE_MAX - DISTANCE_MIN);

        // Determine position at which car reaches signal (at  
        // end of section of road). To accommodate zero-based  
        // array indices, subtracts 1.  
        signalPos[intersection] = roadLength - 1;

        // Allow user to choose type of light at intersection.  
        cout << "\nLight type (intersection #" << (intersection + 1)
            << "):" << endl;
        cout << "n) Normal light" << endl;
        cout << "a) Abbreviated light" << endl;
        cout << "s) Same as previous light" << endl;
        cout << "Type> ";
        char lightType;
        cin >> lightType;

        // Create requested type of traffic light.  

        // int steps;  // number of steps in duration of light

        switch (tolower(lightType))
        {
        case 'a':
            signals[intersection] = LIGHT_ABBREV;
            /*cout << "How long does light last (timesteps): ";
            cin >> steps;*/

            // This function will determine how long the light should remain in the LIGHT_ABBREV state.
            setLightDuration(signals[intersection]);

            break;

        case 's':
            if (intersection > 0)
                signals[intersection] = signals[intersection - 1];
            else
                cout << "Error: No previous light to copy." << endl;

            break;

        default:  // assume normal light  
            signals[intersection] = LIGHT_NORMAL;
            /*cout << "How long does light last (timesteps): ";
             cin >> steps;*/
            setLightDuration(signals[intersection]);
            break;
        }
    }

    // Eat any additional chars and newline from last user input.  
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    // Drive car down road, waiting for lights as required.  
    cout << "\nDriving...Press Enter to advance timestep" << endl;

    // Characters for drawing road with car.  
    const char ROAD = '=';
    const char CAR = '>';

    // Track where car is along road.  
    int carPosition = 0;

    // Drive car all the way to end of road.  
    while (true)
    {
        // Display lights, road, car at next timestep.  
        cout << endl;

        // Display status of all lights (color and time left).  
        displayTrafficLights(signals, NUM_SIGNALS);

        // Draw the road for this timestep and decide whether  
        // car can move next timestep.  
        bool moveCar = true;
        // Track before/at what intersection as draw road.  
        int intersection = 0;

        for (int roadPosition = 0; roadPosition < roadLength; roadPosition++)
        {
            if (roadPosition == carPosition)
                cout << CAR;
            else
                cout << ROAD;

            // If position is intersection, display light #.  
            if (roadPosition == signalPos[intersection])
            {
                cout << "(" << (intersection + 1) << ")";

                // If car is at intersection, decide whether  
                // car moves (due to light color).  
                if (roadPosition == carPosition)
                {
                    string color = signals[intersection].getCurrentLight();
                    if (color == "red")
                        moveCar = false;  // don't move  
                    else if (color == "yellow" && rand() % 3 == 0)
                        moveCar = false;  // don't move 1/3 of time  
                }

                intersection++;
            }
        }

        // Check whether car reached end of road. If so, done.  
        if (carPosition == roadLength)
        {
            cout << CAR << endl;
            break;
        }

        // Move car if not stopped at a light.  
        if (moveCar)
            carPosition++;

        // Advance traffic lights.  
        for (int i = 0; i < NUM_SIGNALS; i++)
            ++signals[i];

        // Allow user to press Enter to advance timestep.  
        string entered;
        getline(cin, entered);
    }
    // clean up dynamic memory
    delete[] signals;
    delete[] signalPos;


    return 0;
}


// Initialize with no lights.  
TrafficLight::TrafficLight() 
    : lights(NULL), numLights(0), currentLight(0), lightDuration(DEFAULT_LIGHT_DURATION), timer(0)
{

}

// Initialize with names for each light.  
TrafficLight::TrafficLight(const string initLights[], int initNumLights) 
    : numLights(initNumLights), currentLight(0), lightDuration(DEFAULT_LIGHT_DURATION), timer(0)
{
    // Create dynamic array to store light names.  
    lights = new string[numLights];

    // Copy each light name from array parameter.  
    for (int i = 0; i < numLights; i++)
        lights[i] = initLights[i];
}

// Copy constructor  
TrafficLight::TrafficLight(const TrafficLight& other) 
    : numLights(other.numLights), currentLight(other.currentLight), lightDuration(other.lightDuration), timer(other.timer)
{
    // Create dynamic array to store light names.  
    lights = new string[numLights];

    // Copy each light name from other object.  
    for (int i = 0; i < numLights; i++)
        lights[i] = other.lights[i];
}

// Destructor  
TrafficLight::~TrafficLight()
{
    // Deallocate dynamic array.  
    delete[] lights;
    lights = NULL;
    numLights = 0;
    currentLight = 0;
    lightDuration = 0;
    timer = 0;
}

// Return name of currently-lit light.  
string TrafficLight::getCurrentLight() const
{
    if (numLights > 0)
        return lights[currentLight];
    return "";
}

// Get time left on the light's timer  
int TrafficLight::getTimeLeft() const
{
    return lightDuration - timer;
}

// Set the duration for each light  
void TrafficLight::setLightDuration(int duration)
{
    lightDuration = duration;
    // Set the index of the current light randomly.  
    srand(static_cast<unsigned int>(time(NULL)));
    currentLight = rand() % numLights;
}

// Assignment operator  
TrafficLight& TrafficLight::operator=(const TrafficLight& other)
{
    if (this != &other)
    {
        // Deallocate old array.  
        delete[] lights;

        // Create dynamic array to store light names.  
        numLights = other.numLights;
        lights = new string[numLights];

        // Copy each light name from other object.  
        for (int i = 0; i < numLights; i++)
            lights[i] = other.lights[i];

        currentLight = other.currentLight;
        lightDuration = other.lightDuration;
        timer = other.timer;
    }
    return *this;
}

// Friend function to advance the traffic light's timer  
TrafficLight& operator++(TrafficLight& light)
{
    light.timer++;
    if (light.timer >= light.lightDuration)
    {
        light.timer = 0;
        light.currentLight = (light.currentLight + 1) % light.numLights;
    }
    return light;
}

// Function to display traffic lights  
void displayTrafficLights(TrafficLight lights[], int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << "(" << (i + 1) << ") " << lights[i].getCurrentLight();
        cout << ": " << lights[i].getTimeLeft() << endl;
    }
}

// Function to set the duration for a traffic light  
void setLightDuration(TrafficLight& light)
{
    int duration;
    cout << "How long does light last (timesteps): ";
    cin >> duration;
    light.setLightDuration(duration);
}
